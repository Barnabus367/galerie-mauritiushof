# Galerie Mauritiushof - HubSpot Theme

Dieses Theme wurde speziell für die Galerie Mauritiushof entwickelt und enthält alle notwendigen Komponenten und Module für die HubSpot-Integration.

## Theme-Struktur

- **templates/**: Enthält alle Seitenvorlagen
  - **layouts/**: Basis-Layouts für alle Seiten
  - **page/**: Spezifische Seitenvorlagen (Home, Artists, Geschichte, etc.)
  - **system/**: Systemseiten wie 404
  
- **modules/**: Wiederverwendbare Module für HubSpot
  - **header.module/**: Header mit Navigation
  - **footer.module/**: Footer mit Kontaktinformationen
  - **hero.module/**: Hero-Banner für Seitentitel
  - **ausstellung.module/**: Modul für aktuelle Ausstellungen
  - **galerie.module/**: Galerie-Modul für Künstler und Werke
  - **kontakt.module/**: Modul für Kontaktformular und -informationen
  
- **css/**: Stylesheets für das Theme
  - **main.css**: Hauptstylesheet mit allen Styles

- **js/**: JavaScript-Dateien
  - **main.js**: Hauptskript mit allen Funktionen

## Installation

1. Melden Sie sich bei Ihrem HubSpot-Account an
2. Gehen Sie zu Marketing > Website > Website-Themes
3. Klicken Sie auf "Theme importieren"
4. Wählen Sie die ZIP-Datei dieses Themes aus
5. Warten Sie, bis der Import abgeschlossen ist

## Anpassung

Alle Module können im HubSpot-Editor angepasst werden. Die Module enthalten editierbare Felder für:

- Texte und Überschriften
- Bilder und Medien
- Links und Buttons
- Farben und Stile (über globale Stile)

## Verwendung

1. Erstellen Sie eine neue Seite in HubSpot
2. Wählen Sie eine der Vorlagen aus (Home, Artists, Geschichte, etc.)
3. Passen Sie die Module nach Ihren Bedürfnissen an
4. Veröffentlichen Sie die Seite

## Module und ihre Verwendung

### Header-Modul
Enthält das Logo und die Hauptnavigation der Website.

### Footer-Modul
Enthält Kontaktinformationen, Logo und Links.

### Hero-Modul
Ein Banner-Modul für die Hauptüberschriften der Seiten mit optionalem Hintergrundbild.

### Ausstellungs-Modul
Zeigt Details zu aktuellen Ausstellungen mit Bild, Titel, Datum und Beschreibung an.

### Galerie-Modul
Zeigt eine Reihe von Bildern mit Overlay-Informationen - perfekt für Künstlerporträts oder Kunstwerke.

### Kontakt-Modul
Enthält Kontaktinformationen, ein Kontaktformular und eine Google Maps-Einbettung.

## Funktionen des Themes

1. **Responsives Design**: Optimiert für alle Bildschirmgrößen
2. **Moderne Animations- und Übergangseffekte**: Verbessert die Benutzererfahrung
3. **Anpassbare Farben und Schriften**: Über globale Stile in HubSpot konfigurierbar
4. **Optimierte Ladezeiten**: Effiziente Code-Strukturen für schnelle Ladezeiten
5. **Einfache Bearbeitung**: Alle Inhalte sind über den HubSpot-Editor bearbeitbar

## Kontakt

Bei Fragen zur Integration wenden Sie sich bitte an:
- E-Mail: galerie@mauritiushof.ch